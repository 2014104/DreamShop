      document.write("<p style='display:inline;font-size:40px;position:absolute;left:50px;top:30px;'>");
      document.write("图书管理系统");
      document.write("</p>");
 
