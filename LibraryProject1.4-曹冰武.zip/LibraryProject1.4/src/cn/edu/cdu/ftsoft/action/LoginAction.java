package cn.edu.cdu.ftsoft.action;

import java.util.Map;

import cn.edu.cdu.ftsoft.dao.ReaderDao;
import cn.edu.cdu.ftsoft.model.Reader;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;


public class LoginAction extends ActionSupport{
	private String readerId;
	private String password;
	private ReaderDao stud=new ReaderDao();
	public String login(){
		Reader stu=null;
		ActionContext ct=ActionContext.getContext();
		Map session=ct.getSession();
		try {
			stu=stud.checkByReaderIdPas(readerId, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(stu==null){
			return INPUT;
		}else{
			session.put("readerId",readerId);
			return SUCCESS;
		}
	}
	public String getReaderId() {
		return readerId;
	}
	public void setReaderId(String readerId) {
		this.readerId = readerId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
