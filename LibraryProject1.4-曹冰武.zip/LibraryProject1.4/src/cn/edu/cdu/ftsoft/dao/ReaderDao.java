package cn.edu.cdu.ftsoft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



import cn.edu.cdu.ftsoft.daoImpl.ReaderDaoImpl;
import cn.edu.cdu.ftsoft.model.Reader;
import cn.edu.cdu.ftsoft.util.C3P0Util;

public class ReaderDao implements ReaderDaoImpl {
	PreparedStatement ps = null;
	ResultSet rs = null;
	Connection conn=null;
	
	public void addReader(Reader c) {
		conn = C3P0Util.getConnection();
		String sql = "insert into reader values (?,?,?,?,?)";
		
	}

	public void updateReader(Reader stu) {
		conn = C3P0Util.getConnection();
		try {
			ps = conn.prepareStatement("update reader set num=? where readerId=?");
			ps.setInt(1, stu.getNum());
			ps.setString(2, stu.getReaderId());
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			C3P0Util.release(conn, ps, null);
		}
	}

	public List<Reader> listReader() {
		conn = C3P0Util.getConnection();
		String sql = "select * from student";
		try {
		ps = conn.prepareStatement(sql);
		List<Reader> StuList = new ArrayList<Reader>();
		    rs = ps.executeQuery();
			Reader c = null;
			while (rs.next()) {
				c = new Reader();
				StuList.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			C3P0Util.release(conn, ps, rs);
		}
		return null;
	}

	public Reader checkByReaderId(String readerId) {
		conn = C3P0Util.getConnection();
		String sql = "select * from reader where readerId=?";
		Reader stu = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, readerId);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				stu=new Reader();
				stu.setReaderId(rs.getString(1));
				stu.setPassword(rs.getString(2));
				stu.setRole(rs.getInt(3));
				stu.setName(rs.getString(4));
				stu.setSex(rs.getString(5));
				stu.setBorn(rs.getDate(6));
				stu.setPhoto(rs.getString(7));
				stu.setPlace(rs.getString(8));
				stu.setEmail(rs.getString(9));
				stu.setTelephoto(rs.getString(10));
				stu.setNum(rs.getInt(11));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
						C3P0Util.release(conn, ps, null);
			
		}
		return stu;

	}

	public void deleteByReaderId(String ReaderId) {
		conn = C3P0Util.getConnection();
		String sql = "delete from student where studentNo = ?";
		try {
		    ps = conn.prepareStatement(sql);
			ps.setString(1, ReaderId);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			C3P0Util.release(conn, ps, null);
		}
		
	}

	public void updatePassword(String ReaderId, String password) {
		conn = C3P0Util.getConnection();
		String sql = "update student set password = ? where studentNo = ?";
		try {
		    ps = conn.prepareStatement(sql);
			ps.setString(1, password);
			ps.setString(2, ReaderId);
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			C3P0Util.release(conn, ps, null);
		}
		
	}

	/*
	 * public static void main(String[] args){ System.out.print("xxx");
	 * DB.createConn(); }
	 */

	public Reader checkByReaderIdPas(String readerId, String password) {
		conn = C3P0Util.getConnection();
		String sql = "select readerId,password from reader where readerId=? and password=?";
		Reader stu = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, readerId);
			ps.setString(2, password);
			rs = ps.executeQuery();
			if (rs.next()) {
				stu = new Reader();
				stu.setReaderId(rs.getString("readerId"));
				stu.setPassword(rs.getString("password"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
		return stu;
	}
}
