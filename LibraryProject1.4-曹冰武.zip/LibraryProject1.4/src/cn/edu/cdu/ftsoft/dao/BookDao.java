package cn.edu.cdu.ftsoft.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;





import cn.edu.cdu.ftsoft.daoImpl.BookDaoImpl;
import cn.edu.cdu.ftsoft.model.Book;
import cn.edu.cdu.ftsoft.util.C3P0Util;
public class BookDao implements BookDaoImpl{
	Connection conn=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	
	public Book selectBook(String bookId){
		try{
			conn=C3P0Util.getConnection();
			ps=conn.prepareStatement("select * from book where bookId=?");
			ps.setString(1, bookId);
			rs=ps.executeQuery();
			if(rs.next()){
				Book book=new Book();
				book.setBookId(rs.getString(1));
				book.setBookName(rs.getString(2));
				book.setISBN(rs.getString(3));
				book.setAuthor(rs.getString(4));
				book.setPublisher(rs.getString(5));
				book.setCnum(rs.getInt(6));
				book.setTypeName(rs.getString(7));
				book.setPhoto(rs.getString(8));
				book.setPrice(rs.getFloat(9));
				return book;
			}else
				return null;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			C3P0Util.release(conn, ps, rs);
		}
	}
	
	public boolean updateBook(Book book){
		try{
			conn=C3P0Util.getConnection();
			ps=conn.prepareStatement("update book set cnum=? where bookId=?");
			ps.setInt(1, book.getCnum());			
			ps.setString(2, book.getBookId());
			System.out.println(book.getCnum());	
			ps.executeUpdate();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			C3P0Util.release(conn, ps, null);
		}
	}
	
	public boolean addBook(Book book){
		try{
			conn=C3P0Util.getConnection();
			ps=conn.prepareStatement("insert into [book] values(?,?,?,?,?,?,?,?,?)");
			ps.setString(1, book.getISBN());
			ps.setString(2, book.getBookName());
			ps.setString(3, book.getAuthor());
			ps.setString(4, book.getPublisher());
			ps.setFloat(5, book.getPrice());
			ps.setInt(6, book.getCnum());
			ps.executeUpdate();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			C3P0Util.release(conn, ps, null);
		}
	}
	
	public boolean deleteBook(String ISBN){
		try{
			conn=C3P0Util.getConnection();
			ps=conn.prepareStatement("delete from [book] where ISBN=?");
			ps.setString(1, ISBN);
			ps.execute();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			C3P0Util.release(conn, ps, null);
		}
	}

}
