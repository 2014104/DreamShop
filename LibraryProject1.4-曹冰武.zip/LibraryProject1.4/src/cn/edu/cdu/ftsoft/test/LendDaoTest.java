package cn.edu.cdu.ftsoft.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import cn.edu.cdu.ftsoft.dao.LendDao;
import cn.edu.cdu.ftsoft.dao.ReaderDao;
import cn.edu.cdu.ftsoft.model.Lend;
import cn.edu.cdu.ftsoft.model.Reader;

public class LendDaoTest {

	@Test
	public void testSelectLend() {
		LendDao rd=new LendDao();
		try {
			List re=rd.selectLend("0006", 2, 3);
			for(int i=0;i<re.size();i++){
				Lend l=(Lend) re.get(i);
				System.out.println(l.getBookId()+","+l.getISBN()+","+l.getPrice()+","+l.getPublisher());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//@Test
	public void testSelectLendSize() {
		LendDao rd=new LendDao();
		try {
			int re=rd.selectLendSize("0006");			
            System.out.println(re);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
