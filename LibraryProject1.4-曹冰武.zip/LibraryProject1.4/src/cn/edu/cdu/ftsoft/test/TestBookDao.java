package cn.edu.cdu.ftsoft.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import cn.edu.cdu.ftsoft.dao.BookDao;
import cn.edu.cdu.ftsoft.dao.LendDao;
import cn.edu.cdu.ftsoft.dao.ReaderDao;
import cn.edu.cdu.ftsoft.model.Book;
import cn.edu.cdu.ftsoft.model.Lend;
import cn.edu.cdu.ftsoft.model.Reader;

public class TestBookDao {

	@Test
	public void testSelectBook() {
		BookDao bd=new BookDao();
		Book b=bd.selectBook("111");
		System.out.println(b.getBookId()+","+b.getBookName());
	}

}
